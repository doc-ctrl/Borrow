﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Borrow.Models
{
    public class Rec
    {
        public int id;
        public string Book = "";
        public string Genre = "";
        public string Author = "";
        public string Member = "";
    }
}
