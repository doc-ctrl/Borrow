﻿namespace Borrow.Repo
{
    internal class Public
    {
    }
}